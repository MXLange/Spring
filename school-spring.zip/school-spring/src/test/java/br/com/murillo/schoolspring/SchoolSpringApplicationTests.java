package br.com.murillo.schoolspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
