package br.com.murillo.schoolspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolSpringApplication.class, args);
	}

}
